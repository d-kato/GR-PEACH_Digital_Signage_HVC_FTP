#ifndef  TELOP_H
#define  TELOP_H

#ifdef  __cplusplus
extern "C" {  /* Start of C Symbol */
#endif

extern const uint8_t  g_RGA_Sample_BinaryImage[ 0x0000C820uL ];

#define  telop                          ((const graphics_image_t*)( g_RGA_Sample_BinaryImage + 0x00000000 ))

#ifdef  __cplusplus
 }  /* End of C Symbol */ 
#endif

#endif /* TELOP_H */
