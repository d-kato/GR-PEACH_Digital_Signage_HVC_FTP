  ((( vbslib 5 - Short Hand Library )))

vbslib makes it easy to use VBScript on WSH. You can make programs easily.
vbslib runs on Windows XP/7/8 (32bit,64bit).


- scriptlib (folder)  : main vbslib library scripts
- samples (folder) : The sample of other main scripts
- _src (folder)    : Doing the test. Look at _src\_replica\!readme.txt

'// vbslib - VBScript ShortHand Library  ver4.90  Apr.14, 2014
'// vbslib is provided under 3-clause BSD license.
'// Copyright (C) 2007-2014 Sofrware Design Gallery "Sage Plaisir 21" All Rights Reserved.


Sofrware Design Gallery "Sage Plaisir 21"  http://www.sage-p.com/

------------------------------------
Copyright reference of bandled module

vbslib\vbslib\zip\zip_readme.txt

